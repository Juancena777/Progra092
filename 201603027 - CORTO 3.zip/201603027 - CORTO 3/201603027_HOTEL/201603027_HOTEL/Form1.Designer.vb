﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.CBHorarios = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TBNombre = New System.Windows.Forms.TextBox()
        Me.TBNit = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CBTiendas = New System.Windows.Forms.ComboBox()
        Me.lblTienda = New System.Windows.Forms.Label()
        Me.DGVMatriz = New System.Windows.Forms.DataGridView()
        Me.NombreC = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NITC = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TiendaC = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HorariosC = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ValorC = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Descuento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TotalC = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.RegistrarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MostrarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConsultarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LimpiarEntradasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        CType(Me.DGVMatriz, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft YaHei", 10.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.DeepPink
        Me.Label6.Location = New System.Drawing.Point(350, 45)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(198, 26)
        Me.Label6.TabIndex = 29
        Me.Label6.Text = "Hotel Playa Dorada"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft YaHei", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(29, 218)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(53, 19)
        Me.Label4.TabIndex = 25
        Me.Label4.Text = "Valor "
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft YaHei", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(441, 173)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(108, 19)
        Me.Label3.TabIndex = 24
        Me.Label3.Text = "Tipo de pago"
        '
        'CBHorarios
        '
        Me.CBHorarios.FormattingEnabled = True
        Me.CBHorarios.Location = New System.Drawing.Point(588, 173)
        Me.CBHorarios.Name = "CBHorarios"
        Me.CBHorarios.Size = New System.Drawing.Size(121, 24)
        Me.CBHorarios.TabIndex = 23
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft YaHei", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(29, 93)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 19)
        Me.Label2.TabIndex = 22
        Me.Label2.Text = "Nombre"
        '
        'TBNombre
        '
        Me.TBNombre.Location = New System.Drawing.Point(118, 89)
        Me.TBNombre.Name = "TBNombre"
        Me.TBNombre.Size = New System.Drawing.Size(222, 22)
        Me.TBNombre.TabIndex = 21
        '
        'TBNit
        '
        Me.TBNit.Location = New System.Drawing.Point(118, 127)
        Me.TBNit.Name = "TBNit"
        Me.TBNit.Size = New System.Drawing.Size(182, 22)
        Me.TBNit.TabIndex = 20
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft YaHei", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(29, 130)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 19)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "Nit"
        '
        'CBTiendas
        '
        Me.CBTiendas.FormattingEnabled = True
        Me.CBTiendas.Location = New System.Drawing.Point(209, 172)
        Me.CBTiendas.Name = "CBTiendas"
        Me.CBTiendas.Size = New System.Drawing.Size(121, 24)
        Me.CBTiendas.TabIndex = 18
        '
        'lblTienda
        '
        Me.lblTienda.AutoSize = True
        Me.lblTienda.Font = New System.Drawing.Font("Microsoft YaHei", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTienda.Location = New System.Drawing.Point(29, 173)
        Me.lblTienda.Name = "lblTienda"
        Me.lblTienda.Size = New System.Drawing.Size(151, 19)
        Me.lblTienda.TabIndex = 17
        Me.lblTienda.Text = "Tipo de Habitacion"
        '
        'DGVMatriz
        '
        Me.DGVMatriz.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.DGVMatriz.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGVMatriz.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.NombreC, Me.NITC, Me.TiendaC, Me.HorariosC, Me.ValorC, Me.Descuento, Me.TotalC})
        Me.DGVMatriz.Location = New System.Drawing.Point(3, 298)
        Me.DGVMatriz.Name = "DGVMatriz"
        Me.DGVMatriz.RowHeadersWidth = 51
        Me.DGVMatriz.RowTemplate.Height = 24
        Me.DGVMatriz.Size = New System.Drawing.Size(881, 150)
        Me.DGVMatriz.TabIndex = 16
        '
        'NombreC
        '
        Me.NombreC.HeaderText = "Nombre"
        Me.NombreC.MinimumWidth = 6
        Me.NombreC.Name = "NombreC"
        Me.NombreC.Width = 125
        '
        'NITC
        '
        Me.NITC.HeaderText = "NIT"
        Me.NITC.MinimumWidth = 6
        Me.NITC.Name = "NITC"
        Me.NITC.Width = 125
        '
        'TiendaC
        '
        Me.TiendaC.HeaderText = "Habitacion"
        Me.TiendaC.MinimumWidth = 6
        Me.TiendaC.Name = "TiendaC"
        Me.TiendaC.Width = 125
        '
        'HorariosC
        '
        Me.HorariosC.HeaderText = "Horarios"
        Me.HorariosC.MinimumWidth = 6
        Me.HorariosC.Name = "HorariosC"
        Me.HorariosC.Width = 125
        '
        'ValorC
        '
        Me.ValorC.HeaderText = "Valor"
        Me.ValorC.MinimumWidth = 6
        Me.ValorC.Name = "ValorC"
        Me.ValorC.Width = 125
        '
        'Descuento
        '
        Me.Descuento.HeaderText = "Descuento"
        Me.Descuento.MinimumWidth = 6
        Me.Descuento.Name = "Descuento"
        Me.Descuento.Width = 125
        '
        'TotalC
        '
        Me.TotalC.HeaderText = "Total"
        Me.TotalC.MinimumWidth = 6
        Me.TotalC.Name = "TotalC"
        Me.TotalC.Width = 125
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Aqua
        Me.MenuStrip1.Font = New System.Drawing.Font("Segoe UI Semibold", 10.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RegistrarToolStripMenuItem, Me.MostrarToolStripMenuItem, Me.ConsultarToolStripMenuItem, Me.LimpiarEntradasToolStripMenuItem, Me.SalirToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(884, 31)
        Me.MenuStrip1.TabIndex = 15
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'RegistrarToolStripMenuItem
        '
        Me.RegistrarToolStripMenuItem.Name = "RegistrarToolStripMenuItem"
        Me.RegistrarToolStripMenuItem.Size = New System.Drawing.Size(93, 27)
        Me.RegistrarToolStripMenuItem.Text = "Registrar"
        '
        'MostrarToolStripMenuItem
        '
        Me.MostrarToolStripMenuItem.Name = "MostrarToolStripMenuItem"
        Me.MostrarToolStripMenuItem.Size = New System.Drawing.Size(82, 27)
        Me.MostrarToolStripMenuItem.Text = "Mostrar"
        '
        'ConsultarToolStripMenuItem
        '
        Me.ConsultarToolStripMenuItem.Name = "ConsultarToolStripMenuItem"
        Me.ConsultarToolStripMenuItem.Size = New System.Drawing.Size(98, 27)
        Me.ConsultarToolStripMenuItem.Text = "Consultar"
        '
        'LimpiarEntradasToolStripMenuItem
        '
        Me.LimpiarEntradasToolStripMenuItem.Name = "LimpiarEntradasToolStripMenuItem"
        Me.LimpiarEntradasToolStripMenuItem.Size = New System.Drawing.Size(156, 27)
        Me.LimpiarEntradasToolStripMenuItem.Text = "Limpiar entradas"
        '
        'SalirToolStripMenuItem
        '
        Me.SalirToolStripMenuItem.Name = "SalirToolStripMenuItem"
        Me.SalirToolStripMenuItem.Size = New System.Drawing.Size(89, 27)
        Me.SalirToolStripMenuItem.Text = "Eliminar"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(109, 218)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 24)
        Me.ComboBox1.TabIndex = 30
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(884, 524)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.CBHorarios)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TBNombre)
        Me.Controls.Add(Me.TBNit)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.CBTiendas)
        Me.Controls.Add(Me.lblTienda)
        Me.Controls.Add(Me.DGVMatriz)
        Me.Controls.Add(Me.MenuStrip1)
        Me.DoubleBuffered = True
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.DGVMatriz, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label6 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents CBHorarios As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents TBNombre As TextBox
    Friend WithEvents TBNit As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents CBTiendas As ComboBox
    Friend WithEvents lblTienda As Label
    Friend WithEvents DGVMatriz As DataGridView
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents MostrarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ConsultarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LimpiarEntradasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SalirToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NombreC As DataGridViewTextBoxColumn
    Friend WithEvents NITC As DataGridViewTextBoxColumn
    Friend WithEvents TiendaC As DataGridViewTextBoxColumn
    Friend WithEvents HorariosC As DataGridViewTextBoxColumn
    Friend WithEvents ValorC As DataGridViewTextBoxColumn
    Friend WithEvents Descuento As DataGridViewTextBoxColumn
    Friend WithEvents TotalC As DataGridViewTextBoxColumn
    Friend WithEvents RegistrarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ComboBox1 As ComboBox
End Class
