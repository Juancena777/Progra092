﻿Public Class Form1
    Private Sub SalirToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SalirToolStripMenuItem.Click
        Dim mv = MsgBox("¿Deseas salir?", vbYesNo)
        If mv = vbYes Then
            MsgBox("Adios jiji")
            Me.Close()
        Else
            MsgBox("No se cerrara")
        End If
    End Sub

    Private Sub LimpiarEntradasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LimpiarEntradasToolStripMenuItem.Click
        TBNombre.Clear()
        TBNit.Clear()
        CBHorarios.Text = ""
        CBTiendas.Text = ""

        TBNombre.Focus()

    End Sub

    Private Sub RegistrarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RegistrarToolStripMenuItem.Click
        Dim hotel, horario, nit, nombre As String
        Dim Valor As Double
        hotel = CBTiendas.Text
        horario = CBHorarios.Text
        nit = TBNit.Text
        nombre = TBNombre.Text
        Valor = Val(ComboBox1.Text)
        If hotel IsNot "" And horario IsNot "" Then
            If nit IsNot "" And nombre IsNot "" Then
                If Valor > 0 Then
                    Registrar(hotel, horario, nit, nombre, Valor)
                Else
                    MsgBox("Ingrese datos correctos")
                End If
            Else
                MsgBox("Se debe de llenar los datos del cliente")
            End If
        Else
            MsgBox("Se deben de llenar los datos del hotel")
        End If

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CBTiendas.Items.Add("Sencilla")
        CBTiendas.Items.Add("Doble")
        CBTiendas.Items.Add("Cabaña")


        CBHorarios.Items.Add("Tarjeta")
        CBHorarios.Items.Add("Efectivo")
        CBHorarios.Items.Add("Deposito")
    End Sub


    Private Sub MostrarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MostrarToolStripMenuItem.Click
        mostrar()
    End Sub

    Private Sub TBValor_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub lblTienda_Click(sender As Object, e As EventArgs) Handles lblTienda.Click

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub
End Class
