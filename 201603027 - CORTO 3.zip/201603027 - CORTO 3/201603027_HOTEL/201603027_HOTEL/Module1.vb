﻿Module Module1
    Public matriz(9, 6) As String
    Public i As Integer = 0

    Friend Sub Registrar(habitacion As String, horario As String, nit As String, nombre As String, monto As Double)
        If i < 10 Then
            Dim total As Double
            Dim desc As Double
            desc = descuento(nit, horario)
            total = monto - monto * desc

            matriz(i, 0) = nombre
            matriz(i, 1) = nit
            matriz(i, 2) = habitacion
            matriz(i, 3) = horario
            matriz(i, 4) = Math.Round(monto, 2)
            matriz(i, 5) = Math.Round(monto * desc, 2)
            matriz(i, 6) = Math.Round(total, 2)
            i = i + 1
            MsgBox("Datos registrado exitosamente")
        Else
            MsgBox("La matriz llena.")
        End If
        mostrar()
    End Sub
    Sub mostrar()
        Form1.DGVMatriz.Rows.Clear()
        For ind As Integer = 0 To 9
            If matriz(ind, 0) <> Nothing Then
                Form1.DGVMatriz.Rows.Add(matriz(ind, 0), matriz(ind, 1), matriz(ind, 2), matriz(ind, 3), matriz(ind, 4), matriz(ind, 5), matriz(ind, 6))
            End If
        Next
    End Sub
    Function descuento(nit As String, horario As String) As Double
        Dim bandera As Boolean = False
        For ind As Integer = 0 To 9
            If matriz(ind, 0) <> Nothing Then
                If matriz(ind, 2) = nit Then
                    bandera = True
                    If matriz(ind, 1) = horario Then
                        Return 0.1
                    End If
                End If
            End If
        Next
        If bandera = True Then
            Return 0.05
        Else
            Return 0
        End If


    End Function




End Module
