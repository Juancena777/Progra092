﻿Public Class Form1
    Private Sub CBCursos_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CBCosas.SelectedIndexChanged

    End Sub

    Private Sub SalirToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SalirToolStripMenuItem.Click
        Dim mv = MsgBox("¿Deseas salir? ESTE BOTON FUNCIONA BIEN", vbYesNo)
        If mv = vbYes Then
            MsgBox("Adios jiji")
            Me.Close()
        Else
            MsgBox("No se cerrara")
        End If
    End Sub

    Private Sub LimpiarEntradasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LimpiarEntradasToolStripMenuItem.Click
        limpiarentradas()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim Producto As String
        Dim Total As String
        Dim tablet, dron, celular, televisor As Integer
        Producto = CBCosas.SelectedItem

        If TBNombreV.Text IsNot "" Then
            Select Case Producto
                Case "TABLET"
                    tablet = 375

                    TBPrecio.Text = tablet
                Case "DRON"
                    dron = 560

                    TBPrecio.Text = dron
                Case "CELULAR"
                    celular = 1450

                    TBPrecio.Text = celular
                Case "TELEVISON"
                    televisor = 3250

                    TBPrecio.Text = televisor
            End Select

            DGVDatos.Rows.Add()
            Dim CantFilas = DGVDatos.Rows.Count - 1
            DGVDatos(0, CantFilas).Value = TBNombreV.Text
            DGVDatos(1, CantFilas).Value = CBCosas.Text
            DGVDatos(2, CantFilas).Value = TBPrecio.Text
            DGVDatos(3, CantFilas).Value = Total
        Else
            MsgBox("Debe Seleccionar un curso")

        End If
    End Sub

    Private Sub TBNombreV_TextChanged(sender As Object, e As EventArgs) Handles TBNombreV.TextChanged

    End Sub

    Private Sub DGVDatos_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGVDatos.CellContentClick

    End Sub
End Class
