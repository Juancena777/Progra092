﻿Module Module1
    Public desc1 = 0.7, desc2 = 0.3, desc3 = 0.2, desc4 = 0.5
    Public curso1 = 650, curso2 = 675, curso3 = 600, curso4 = 550


    Sub limpiarentradas()
        Form1.TBNombreV.Clear()
        Form1.CBCosas.Text = ""
        Form1.TBPrecio.Clear()
        Form1.TBNombreV.Focus()

    End Sub
End Module
