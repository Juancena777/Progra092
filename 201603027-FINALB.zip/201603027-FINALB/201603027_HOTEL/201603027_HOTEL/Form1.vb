﻿Public Class Form1
    Dim PFinal As Double
    Dim PHabitacion
    Dim Extras As Double

    Private Sub AceptarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AceptarToolStripMenuItem.Click

        Dim tipo As String
        tipo = txtTipo.Text

        Select Case tipo
            Case "Estandar"
                PHabitacion = 250
            Case "AC"
                PHabitacion = 290
            Case "Jacuzi"
                PHabitacion = 370
        End Select


        Dim Personas As Double
        Personas = txtCant.Text

        If Personas > 4 Then
            Dim PerExt As Double
            PerExt = Personas - 4
            Extras = PerExt * 60
        End If

        PFinal = PHabitacion + Extras


    End Sub

    Private Sub LimpiarDataGridViewToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LimpiarDataGridViewToolStripMenuItem.Click
        Dim n = DataGridView1.Rows.Add

        DataGridView1.Rows(n).Cells(0).Value = txtNit.Text
        DataGridView1.Rows(n).Cells(1).Value = txtNombre.Text
        DataGridView1.Rows(n).Cells(2).Value = txtCant.Text
        DataGridView1.Rows(n).Cells(3).Value = txtTipo.Text
        DataGridView1.Rows(n).Cells(4).Value = Extras
        DataGridView1.Rows(n).Cells(5).Value = PFinal

        txtNit.Text = ""
        txtNombre.Text = ""
        txtCant.Text = ""

    End Sub

    Private Sub LimpiarVectoresToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LimpiarVectoresToolStripMenuItem.Click
        DataGridView1.Rows.Clear()
        txtNit.Text = ""
        txtNombre.Text = ""
        txtCant.Text = ""
    End Sub

    Private Sub SalirToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SalirToolStripMenuItem.Click
        If (MsgBox("¿QUIERE SALIR DEL SISTEMA?", vbQuestion + vbYesNo, "MENSAJE DE SALIDA") = vbYes) Then
            Me.Close()
            End
        End If
    End Sub


End Class
